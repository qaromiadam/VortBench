# Benchy

Benchy is an offline-first Android hardware benchmarking, device health, and app security suite. It is built with Kotlin, Jetpack Compose (Material 3), Android NDK/JNI (C++17), Room, Preferences DataStore, WorkManager, and Google ML Kit On-Device Translation.

## Run locally

**Prerequisites:** [Android Studio](https://developer.android.com/studio)

1. Open Android Studio and select **Open**, then choose this project directory.
2. Let Android Studio finish the Gradle sync.
3. Run the app on an emulator or a physical device (Android 10 / API 29 or newer).

## Release signing

Release builds are signed only when the `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` environment variables are set. Without them, release builds are unsigned.
