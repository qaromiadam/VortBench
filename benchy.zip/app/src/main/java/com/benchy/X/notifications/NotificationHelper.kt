package com.benchy.X.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.benchy.X.MainActivity
import com.benchy.X.R
import java.util.concurrent.atomic.AtomicInteger

data class NotificationAudioDiagnostic(
    val permissionGranted: Boolean,
    val notificationsEnabled: Boolean,
    val channelImportanceOk: Boolean,
    val channelHasSound: Boolean,
    val notifStreamVolume: Int,
    val notifStreamMax: Int,
    val ringerNormal: Boolean,
    val dndActive: Boolean
)

object NotificationHelper {

    // Channel sound is fixed at creation time on Android 8+, so the ID is bumped whenever the sound changes.
    const val CHANNEL_GOOD_ALERTS = "benchy_good_alerts_v7"
    const val CHANNEL_BAD_ALERTS = "benchy_bad_alerts_v7"
    const val CHANNEL_SCAN_PROGRESS = "benchy_scan_progress"
    const val CHANNEL_BATTERY_TRACKER = "benchy_battery_tracker"

    const val NOTIF_ID_ALERT = 1001
    const val NOTIF_ID_ANTIVIRUS = 1002
    private const val NOTIF_ID_TEST_BASE = 1100
    const val NOTIF_ID_LONG_SCAN = 2001
    const val NOTIF_ID_BATTERY_TRACKER = 2002

    private val LEGACY_CHANNEL_IDS = listOf(
        "benchy_good_alerts", "benchy_bad_alerts",
        "benchy_good_alerts_v2", "benchy_bad_alerts_v2",
        "benchy_good_alerts_v3", "benchy_bad_alerts_v3",
        "benchy_good_alerts_v4", "benchy_bad_alerts_v4",
        "benchy_good_alerts_v5", "benchy_bad_alerts_v5",
        "benchy_good_alerts_v6", "benchy_bad_alerts_v6"
    )

    private val testAlertSeq = AtomicInteger(0)

    // In-app preview pool (USAGE_MEDIA so the Settings tester is audible even at low notification volume)
    @Volatile
    private var previewPool: SoundPool? = null
    @Volatile
    private var previewGoodId = 0
    @Volatile
    private var previewBadId = 0
    private val loadedPreviewIds = mutableSetOf<Int>()
    @Volatile
    private var pendingPreviewGood: Boolean? = null

    fun getNotificationSoundUri(context: Context, isPositive: Boolean): Uri {
        val rawResId = if (isPositive) R.raw.ding_ding else R.raw.dong_dong
        return Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/$rawResId")
    }

    fun initializeChannels(context: Context) {
        val appCtx = context.applicationContext
        val manager = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        runCatching {
            LEGACY_CHANNEL_IDS.forEach { oldId ->
                if (manager.getNotificationChannel(oldId) != null) {
                    manager.deleteNotificationChannel(oldId)
                }
            }
        }

        val alertAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        ensureAlertChannel(
            manager = manager,
            context = appCtx,
            channelId = CHANNEL_GOOD_ALERTS,
            name = "Benchy Positive Alerts (Ding-Ding)",
            description = "Positive benchmark scores (>50%), healthy diagnostics, and 0-threat antivirus results.",
            isPositive = true,
            vibrate = false,
            audioAttrs = alertAttrs
        )
        ensureAlertChannel(
            manager = manager,
            context = appCtx,
            channelId = CHANNEL_BAD_ALERTS,
            name = "Benchy Warning Alerts (Dong-Dong)",
            description = "Low performance scores (<=50%), thermal warnings, and suspicious app alerts.",
            isPositive = false,
            vibrate = true,
            audioAttrs = alertAttrs
        )

        if (manager.getNotificationChannel(CHANNEL_SCAN_PROGRESS) == null) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_SCAN_PROGRESS,
                    "Benchy 2-Hour Long Scan",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Live progress notification for active 2-hour hardware & security scans."
                    setSound(null, null)
                }
            )
        }

        if (manager.getNotificationChannel(CHANNEL_BATTERY_TRACKER) == null) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_BATTERY_TRACKER,
                    "Benchy 1-Week Battery Tracker",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Persistent live telemetry for 7-day battery voltage, current, and temperature logging."
                    setSound(null, null)
                    enableVibration(false)
                }
            )
        }

        getPreviewPool(appCtx)
    }

    /**
     * Creates an alert channel if missing, or recreates it if its sound or importance is wrong.
     * Android fixes a channel's sound at creation, so a broken channel can only be repaired this way.
     */
    private fun ensureAlertChannel(
        manager: NotificationManager,
        context: Context,
        channelId: String,
        name: String,
        description: String,
        isPositive: Boolean,
        vibrate: Boolean,
        audioAttrs: AudioAttributes
    ) {
        val expectedSound = getNotificationSoundUri(context, isPositive).toString()
        val existing = manager.getNotificationChannel(channelId)
        if (existing != null &&
            (existing.sound?.toString() != expectedSound || existing.importance < NotificationManager.IMPORTANCE_HIGH)
        ) {
            manager.deleteNotificationChannel(channelId)
        }
        if (manager.getNotificationChannel(channelId) == null) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, name, NotificationManager.IMPORTANCE_HIGH).apply {
                    this.description = description
                    setSound(getNotificationSoundUri(context, isPositive), audioAttrs)
                    enableVibration(vibrate)
                }
            )
        }
    }

    private fun getPreviewPool(context: Context): SoundPool {
        previewPool?.let { return it }
        synchronized(this) {
            previewPool?.let { return it }
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val pool = SoundPool.Builder()
                .setMaxStreams(2)
                .setAudioAttributes(attrs)
                .build()
            pool.setOnLoadCompleteListener { p, sampleId, status ->
                if (status != 0) return@setOnLoadCompleteListener
                synchronized(this) {
                    loadedPreviewIds += sampleId
                    val pending = pendingPreviewGood
                    if (pending != null && sampleId == (if (pending) previewGoodId else previewBadId)) {
                        pendingPreviewGood = null
                        p.play(sampleId, 1f, 1f, 1, 0, 1f)
                    }
                }
            }
            previewGoodId = pool.load(context, R.raw.ding_ding, 1)
            previewBadId = pool.load(context, R.raw.dong_dong, 1)
            previewPool = pool
            return pool
        }
    }

    /** Plays the in-app preview of an alert sound from Settings. Plays as soon as the sound has loaded. */
    fun playInAppTone(context: Context, isGood: Boolean) {
        val pool = getPreviewPool(context.applicationContext)
        val sampleId = if (isGood) previewGoodId else previewBadId
        synchronized(this) {
            if (sampleId in loadedPreviewIds) {
                pool.play(sampleId, 1f, 1f, 1, 0, 1f)
            } else {
                pendingPreviewGood = isGood
            }
        }
    }

    fun raiseNotificationStreamVolume(context: Context) {
        runCatching {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val max = am.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION).coerceAtLeast(1)
            val target = (max * 0.8f).toInt().coerceAtLeast(1)
            am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, target, AudioManager.FLAG_SHOW_UI)
        }
    }

    fun inspectNotificationAudioState(context: Context): NotificationAudioDiagnostic {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        val vol = am?.getStreamVolume(AudioManager.STREAM_NOTIFICATION) ?: 1
        val maxVol = am?.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION) ?: 7
        val ringerNormal = (am?.ringerMode ?: AudioManager.RINGER_MODE_NORMAL) == AudioManager.RINGER_MODE_NORMAL
        val enabled = runCatching { NotificationManagerCompat.from(context).areNotificationsEnabled() }.getOrDefault(true)

        val goodCh = runCatching { nm?.getNotificationChannel(CHANNEL_GOOD_ALERTS) }.getOrNull()
        val chImpOk = goodCh == null || goodCh.importance >= NotificationManager.IMPORTANCE_DEFAULT
        val chHasSound = goodCh == null || goodCh.sound != null
        val dndActive = runCatching {
            val filter = nm?.currentInterruptionFilter ?: NotificationManager.INTERRUPTION_FILTER_ALL
            filter != NotificationManager.INTERRUPTION_FILTER_ALL
        }.getOrDefault(false)

        return NotificationAudioDiagnostic(
            permissionGranted = canPostNotifications(context),
            notificationsEnabled = enabled,
            channelImportanceOk = chImpOk,
            channelHasSound = chHasSound,
            notifStreamVolume = vol,
            notifStreamMax = maxVol,
            ringerNormal = ringerNormal,
            dndActive = dndActive
        )
    }

    /**
     * Posts an OS notification on the v7 channel, which is bound to the bundled ding_ding / dong_dong
     * raw resources. Android plays the sound itself, even when the app is closed.
     */
    fun postResultAlert(
        context: Context,
        isPositive: Boolean,
        title: String,
        body: String,
        alertsMuted: Boolean,
        notificationId: Int = NOTIF_ID_ALERT,
        useUniqueTestId: Boolean = false
    ) {
        initializeChannels(context)
        if (!canPostNotifications(context)) return

        val channelId = if (isPositive) CHANNEL_GOOD_ALERTS else CHANNEL_BAD_ALERTS
        val effectiveId = if (useUniqueTestId) {
            NOTIF_ID_TEST_BASE + (testAlertSeq.getAndIncrement() % 10)
        } else {
            notificationId
        }

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingTap = PendingIntent.getActivity(
            context,
            effectiveId,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setContentIntent(pendingTap)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setSilent(alertsMuted)

        runCatching {
            val nm = NotificationManagerCompat.from(context)
            if (!useUniqueTestId) {
                nm.cancel(effectiveId)
            }
            nm.notify(effectiveId, builder.build())
        }
    }

    fun buildLongScanNotification(
        context: Context,
        title: String,
        content: String,
        progressPercent: Int,
        cancelPendingIntent: PendingIntent
    ): Notification {
        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingTap = PendingIntent.getActivity(
            context,
            NOTIF_ID_LONG_SCAN,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_SCAN_PROGRESS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(content)
            .setOngoing(true)
            .setAutoCancel(false)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setProgress(100, progressPercent.coerceIn(0, 100), false)
            .setContentIntent(pendingTap)
            .addAction(0, context.getString(R.string.action_cancel), cancelPendingIntent)
            .build()
        notif.flags = notif.flags or Notification.FLAG_NO_CLEAR or Notification.FLAG_ONGOING_EVENT
        return notif
    }

    fun buildBatteryTrackerNotification(
        context: Context,
        title: String,
        content: String,
        stopPendingIntent: PendingIntent,
        repostPendingIntent: PendingIntent? = null
    ): Notification {
        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingTap = PendingIntent.getActivity(
            context,
            NOTIF_ID_BATTERY_TRACKER,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_BATTERY_TRACKER)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(content)
            .setOngoing(true)
            .setAutoCancel(false)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(pendingTap)
            .addAction(0, context.getString(R.string.action_stop), stopPendingIntent)

        if (repostPendingIntent != null) {
            builder.setDeleteIntent(repostPendingIntent)
        }

        val notif = builder.build()
        notif.flags = notif.flags or Notification.FLAG_NO_CLEAR or Notification.FLAG_ONGOING_EVENT
        return notif
    }

    fun canPostNotifications(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }
}
